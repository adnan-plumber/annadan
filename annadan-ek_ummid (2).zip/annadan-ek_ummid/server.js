// server.js - Main Express Server for Annadan - Ek Ummid
// Food Donation Platform Backend

const express = require('express');
const cors = require('cors');
const path = require('path');
const bcrypt = require('bcryptjs');
require('dotenv').config();

const db = require('./db');
const donorRoutes = require('./routes/donors');
const donationRoutes = require('./routes/donations');
const ngoRoutes = require('./routes/ngos');
const adminRoutes = require('./routes/admin');

// Import Google Gemini SDK
const { GoogleGenerativeAI } = require('@google/generative-ai');


const app = express();
const PORT = process.env.PORT || 3000;

// ==================== MIDDLEWARE ====================

// Enable CORS for all origins (configure in production)
app.use(cors());

// Parse JSON request bodies
app.use(express.json());

// Parse URL-encoded bodies
app.use(express.urlencoded({ extended: true }));

// Serve static files from public directory
app.use(express.static(path.join(__dirname, 'public')));

// ==================== API ROUTES ====================

app.use('/api/donors', donorRoutes);
app.use('/api/donations', donationRoutes);
app.use('/api/ngos', ngoRoutes);
app.use('/api/admin', adminRoutes);

// ==================== CLAUDE AI CHATBOT ====================

/**
 * POST /api/chat
 * Sends message to Claude AI and returns response
 */
app.post('/api/chat', async (req, res) => {
  try {
    const { message, history } = req.body;

    if (!message || message.trim() === '') {
      return res.status(400).json({ success: false, message: 'Message cannot be empty.' });
    }

    // Check if API key is configured
    if (!process.env.GEMINI_API_KEY || process.env.GEMINI_API_KEY === 'your_gemini_api_key_here') {
      return res.status(503).json({
        success: false,
        message: 'AI service not configured. Add GEMINI_API_KEY to .env (free at https://aistudio.google.com/apikey)',
      });
    }

    const genAI = new GoogleGenerativeAI(process.env.GEMINI_API_KEY);
    const model = genAI.getGenerativeModel({
      model: 'gemini-2.0-flash',   // current free-tier model
      systemInstruction: `You are a helpful and warm assistant for Annadan - Ek Ummid, an NGO food donation platform in India.
Your role is to:
- Help food donors understand how to register and donate food (cooked food, raw groceries, packaged food)
- Guide NGOs on how to register and get approved on the platform
- Explain how the pickup process works
- Answer questions about food safety and best practices for donation
- Provide encouragement to donors and NGOs
- Answer in both Hindi and English (Hinglish is welcome!)
- Be warm, encouraging, and concise

Platform Details:
- Donors register at /donor.html and submit food donation forms
- NGOs register at /ngo.html and wait for admin approval
- Food types accepted: Cooked Food, Raw Groceries, Packaged Food
- Admin manages donation statuses: Pending → Accepted → Picked Up

Always be positive and motivate people: "Bachha hua khana, kisi ki ummid bane!"`,
    });

    // Build Gemini chat history format
    const geminiHistory = [];
    if (history && Array.isArray(history)) {
      history.forEach((msg) => {
        if (msg.role === 'user' || msg.role === 'assistant') {
          geminiHistory.push({
            role: msg.role === 'assistant' ? 'model' : 'user',
            parts: [{ text: msg.content }],
          });
        }
      });
    }

    // Start chat session with history
    const chat = model.startChat({ history: geminiHistory });
    const result = await chat.sendMessage(message.trim());
    const reply = result.response.text();

    res.json({ success: true, reply });
  } catch (error) {
    const errMsg = error?.message || String(error);
    console.error('Gemini API error:', errMsg);
    if (error.status === 401 || errMsg.includes('API_KEY') || errMsg.includes('API key') || errMsg.includes('invalid')) {
      return res.status(401).json({ success: false, message: '❌ Invalid Gemini API key. Please check your .env file.' });
    }
    if (error.status === 429 || errMsg.includes('quota') || errMsg.includes('rate')) {
      return res.status(429).json({ success: false, message: '⏳ AI rate limit reached. Try again in a moment.' });
    }
    res.status(500).json({ success: false, message: `AI error: ${errMsg}` });
  }
});



// ==================== DATABASE INITIALIZATION ====================

/**
 * Initialize database tables and default admin account
 */
async function initializeDatabase() {
  try {
    console.log('🔧 Initializing database...');
    
    // First, connect without specifying a database to create it if it doesn't exist
    const mysql = require('mysql2/promise');
    const tempDb = await mysql.createConnection({
      host: process.env.DB_HOST || 'localhost',
      user: process.env.DB_USER || 'root',
      password: process.env.DB_PASSWORD || ''
    });
    const dbName = process.env.DB_NAME || 'annadan';
    await tempDb.query(`CREATE DATABASE IF NOT EXISTS \`${dbName}\``);
    await tempDb.end();

    // Create donors table
    await db.execute(`
      CREATE TABLE IF NOT EXISTS donors (
        id INT AUTO_INCREMENT PRIMARY KEY,
        name VARCHAR(100) NOT NULL,
        phone VARCHAR(15) NOT NULL,
        email VARCHAR(100),
        address TEXT NOT NULL,
        created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
      )
    `);

    // Create donations table
    await db.execute(`
      CREATE TABLE IF NOT EXISTS donations (
        id INT AUTO_INCREMENT PRIMARY KEY,
        donor_id INT,
        food_type VARCHAR(100) NOT NULL,
        quantity VARCHAR(100) NOT NULL,
        time_slot VARCHAR(100) NOT NULL,
        pickup_address TEXT NOT NULL,
        status ENUM('pending','accepted','picked_up') DEFAULT 'pending',
        accepted_by_ngo_id INT DEFAULT NULL,
        created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
        FOREIGN KEY (donor_id) REFERENCES donors(id) ON DELETE SET NULL,
        FOREIGN KEY (accepted_by_ngo_id) REFERENCES ngos(id) ON DELETE SET NULL
      )
    `);

    // Add accepted_by_ngo_id column if upgrading existing DB
    try {
      await db.execute('ALTER TABLE donations ADD COLUMN IF NOT EXISTS accepted_by_ngo_id INT DEFAULT NULL');
    } catch(e) { /* column may already exist */ }

    // Create ngos table
    await db.execute(`
      CREATE TABLE IF NOT EXISTS ngos (
        id INT AUTO_INCREMENT PRIMARY KEY,
        name VARCHAR(150) NOT NULL,
        area VARCHAR(100) NOT NULL,
        contact VARCHAR(15) NOT NULL,
        email VARCHAR(100),
        is_approved TINYINT(1) DEFAULT 0,
        created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
      )
    `);

    // Create admins table
    await db.execute(`
      CREATE TABLE IF NOT EXISTS admins (
        id INT AUTO_INCREMENT PRIMARY KEY,
        username VARCHAR(50) NOT NULL UNIQUE,
        password_hash VARCHAR(255) NOT NULL
      )
    `);

    // Check if default admin exists, if not create one
    const [admins] = await db.execute("SELECT id FROM admins WHERE username = 'admin'");

    if (admins.length === 0) {
      // Hash the default password: admin123
      const hashedPassword = await bcrypt.hash('admin123', 12);
      await db.execute('INSERT INTO admins (username, password_hash) VALUES (?, ?)', [
        'admin',
        hashedPassword,
      ]);
      console.log('✅ Default admin created: username=admin, password=admin123');
    } else {
      console.log('✅ Admin account already exists.');
    }

    console.log('✅ Database initialized successfully!');
  } catch (error) {
    console.error('❌ Database initialization failed:', error.message);
    console.error('   Make sure MySQL is running and credentials in .env are correct.');
    process.exit(1);
  }
}

// ==================== HTML PAGE ROUTES ====================
// Serve the HTML files for each page

app.get('/', (req, res) => {
  res.sendFile(path.join(__dirname, 'public', 'index.html'));
});

app.get('/donor', (req, res) => {
  res.sendFile(path.join(__dirname, 'public', 'donor.html'));
});

app.get('/ngo', (req, res) => {
  res.sendFile(path.join(__dirname, 'public', 'ngo.html'));
});

app.get('/admin', (req, res) => {
  res.sendFile(path.join(__dirname, 'public', 'admin.html'));
});

app.get('/chatbot', (req, res) => {
  res.sendFile(path.join(__dirname, 'public', 'chatbot.html'));
});

// ==================== 404 HANDLER ====================
app.use((req, res) => {
  res.status(404).json({ success: false, message: 'Route not found.' });
});

// ==================== ERROR HANDLER ====================
app.use((err, req, res, next) => {
  console.error('Unhandled error:', err);
  res.status(500).json({ success: false, message: 'Internal server error.' });
});

// ==================== START SERVER ====================
initializeDatabase().then(() => {
  app.listen(PORT, () => {
    console.log('');
    console.log('🍽️  ================================');
    console.log('   Annadan - Ek Ummid Server');
    console.log('🍽️  ================================');
    console.log(`🚀 Server running at: http://localhost:${PORT}`);
    console.log(`📊 Admin Panel:      http://localhost:${PORT}/admin.html`);
    console.log(`🤖 AI Chatbot:       http://localhost:${PORT}/chatbot.html`);
    console.log('');
    console.log('📋 Admin Credentials:');
    console.log('   Username: admin');
    console.log('   Password: admin123');
    console.log('');
  });
});

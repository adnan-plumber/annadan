// db.js - MySQL Database Connection
// Handles connection pooling for the Annadan platform

const mysql = require('mysql2');
require('dotenv').config();

// Create a connection pool for better performance
const pool = mysql.createPool({
  host: process.env.DB_HOST || 'localhost',
  user: process.env.DB_USER || 'root',
  password: process.env.DB_PASSWORD || '',
  database: process.env.DB_NAME || 'annadan',
  waitForConnections: true,
  connectionLimit: 10,
  queueLimit: 0,
});

// Promisify pool for async/await usage
const db = pool.promise();

module.exports = db;

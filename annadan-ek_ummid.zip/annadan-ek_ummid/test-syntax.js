const fs = require('fs');
const html = fs.readFileSync('public/donor.html', 'utf8');
const scriptMatches = html.match(/<script>([\s\S]*?)<\/script>/g);
if (scriptMatches) {
  const scriptContent = scriptMatches[scriptMatches.length - 1].replace(/<\/?script>/g, '');
  try {
    const acorn = require('acorn');
    acorn.parse(scriptContent, { ecmaVersion: 2022, allowAwaitOutsideFunction: true });
    console.log('No Syntax Error found.');
  } catch (e) {
    console.log('SyntaxError:', e.message);
  }
} else {
  console.log('No scripts found');
}

// routes/ngos.js - NGO Registration & Management Routes
// Handles NGO registration, login, and approval for the Annadan platform

const express = require('express');
const router = express.Router();
const db = require('../db');
const { verifyToken } = require('./admin');

/**
 * POST /api/ngos/login
 * NGO Login using NGO ID + registered contact number
 */
router.post('/login', async (req, res) => {
  try {
    const { ngo_id, contact } = req.body;
    if (!ngo_id || !contact) {
      return res.status(400).json({ success: false, message: 'NGO ID and contact number are required.' });
    }
    const [rows] = await db.execute(
      'SELECT id, name, area, contact, is_approved FROM ngos WHERE id = ? AND contact = ?',
      [ngo_id, contact.trim()]
    );
    if (rows.length === 0) {
      return res.status(401).json({ success: false, message: 'Invalid NGO ID or contact number.' });
    }
    const ngo = rows[0];
    if (!ngo.is_approved) {
      return res.status(403).json({
        success: false,
        message: 'Your NGO is pending admin approval. Please wait 24-48 hours.',
      });
    }
    res.json({ success: true, message: `Welcome, ${ngo.name}!`, ngo });
  } catch (error) {
    console.error('NGO login error:', error);
    res.status(500).json({ success: false, message: 'Server error.' });
  }
});

/**
 * POST /api/ngos
 * Register a new NGO
 */
router.post('/', async (req, res) => {
  try {
    const { name, area, contact, email } = req.body;

    if (!name || !area || !contact) {
      return res.status(400).json({
        success: false,
        message: 'Organization name, area, and contact number are required.',
      });
    }

    const phoneRegex = /^[0-9]{10,15}$/;
    if (!phoneRegex.test(contact.replace(/[\s\-\+]/g, ''))) {
      return res.status(400).json({ success: false, message: 'Please provide a valid contact number.' });
    }

    const [result] = await db.execute(
      'INSERT INTO ngos (name, area, contact, email, is_approved) VALUES (?, ?, ?, ?, 1)',
      [name.trim(), area.trim(), contact.trim(), email ? email.trim() : null]
    );

    res.status(201).json({
      success: true,
      message: 'NGO registered and approved successfully! Redirecting to dashboard...',
      ngoId: result.insertId,
    });
  } catch (error) {
    console.error('Error registering NGO:', error);
    res.status(500).json({ success: false, message: 'Server error. Please try again.' });
  }
});

/**
 * GET /api/ngos
 * Get all approved NGOs (public)
 */
router.get('/', async (req, res) => {
  try {
    const [rows] = await db.execute(
      'SELECT id, name, area, contact, email, created_at FROM ngos WHERE is_approved = 1 ORDER BY created_at DESC'
    );
    res.json({ success: true, ngos: rows });
  } catch (error) {
    console.error('Error fetching NGOs:', error);
    res.status(500).json({ success: false, message: 'Server error.' });
  }
});

/**
 * GET /api/ngos/all
 * Get all NGOs including pending (admin only)
 */
router.get('/all', verifyToken, async (req, res) => {
  try {
    const [rows] = await db.execute(
      'SELECT id, name, area, contact, email, is_approved, created_at FROM ngos ORDER BY created_at DESC'
    );
    res.json({ success: true, ngos: rows });
  } catch (error) {
    console.error('Error fetching all NGOs:', error);
    res.status(500).json({ success: false, message: 'Server error.' });
  }
});

/**
 * PUT /api/ngos/:id/approve
 * Approve an NGO (admin only)
 */
router.put('/:id/approve', verifyToken, async (req, res) => {
  try {
    const { id } = req.params;
    const [result] = await db.execute('UPDATE ngos SET is_approved = 1 WHERE id = ?', [id]);
    if (result.affectedRows === 0) {
      return res.status(404).json({ success: false, message: 'NGO not found.' });
    }
    res.json({ success: true, message: 'NGO approved successfully!' });
  } catch (error) {
    console.error('Error approving NGO:', error);
    res.status(500).json({ success: false, message: 'Server error.' });
  }
});

/**
 * DELETE /api/ngos/:id
 * Remove an NGO (admin only)
 */
router.delete('/:id', verifyToken, async (req, res) => {
  try {
    const { id } = req.params;
    const [result] = await db.execute('DELETE FROM ngos WHERE id = ?', [id]);
    if (result.affectedRows === 0) {
      return res.status(404).json({ success: false, message: 'NGO not found.' });
    }
    res.json({ success: true, message: 'NGO removed successfully.' });
  } catch (error) {
    console.error('Error deleting NGO:', error);
    res.status(500).json({ success: false, message: 'Server error.' });
  }
});

module.exports = router;

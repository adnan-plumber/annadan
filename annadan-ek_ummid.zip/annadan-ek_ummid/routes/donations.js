// routes/donations.js - Food Donation Routes
// Manages food donation listings for the Annadan platform

const express = require('express');
const router = express.Router();
const db = require('../db');
const { verifyToken } = require('./admin');

/**
 * GET /api/donations
 * Get all donations with donor + accepted NGO info
 */
router.get('/', async (req, res) => {
  try {
    const [rows] = await db.execute(
      `SELECT d.id, don.name AS donor_name, don.phone AS donor_phone,
              d.food_type, d.quantity, d.time_slot, d.pickup_address,
              d.status, d.accepted_by_ngo_id,
              n.name AS accepted_ngo_name, n.contact AS accepted_ngo_contact,
              d.created_at
       FROM donations d
       LEFT JOIN donors don ON d.donor_id = don.id
       LEFT JOIN ngos n ON d.accepted_by_ngo_id = n.id
       ORDER BY d.created_at DESC
       LIMIT 100`
    );
    res.json({ success: true, donations: rows });
  } catch (error) {
    console.error('Error fetching donations:', error);
    res.status(500).json({ success: false, message: 'Server error.' });
  }
});

/**
 * GET /api/donations/pending
 * Get only pending donations (for NGO dashboard live feed)
 */
router.get('/pending', async (req, res) => {
  try {
    const [rows] = await db.execute(
      `SELECT d.id, don.name AS donor_name, don.phone AS donor_phone,
              d.food_type, d.quantity, d.time_slot, d.pickup_address,
              d.status, d.created_at
       FROM donations d
       LEFT JOIN donors don ON d.donor_id = don.id
       WHERE d.status = 'pending'
       ORDER BY d.created_at DESC`
    );
    res.json({ success: true, donations: rows });
  } catch (error) {
    console.error('Error fetching pending donations:', error);
    res.status(500).json({ success: false, message: 'Server error.' });
  }
});

/**
 * POST /api/donations
 * Submit a new food donation
 */
router.post('/', async (req, res) => {
  try {
    const { donor_id, food_type, quantity, time_slot, pickup_address } = req.body;

    if (!food_type || !quantity || !time_slot || !pickup_address) {
      return res.status(400).json({
        success: false,
        message: 'Food type, quantity, time slot, and pickup address are required.',
      });
    }

    const validFoodTypes = ['Cooked Food', 'Raw Groceries', 'Packaged Food'];
    if (!validFoodTypes.includes(food_type)) {
      return res.status(400).json({
        success: false,
        message: 'Invalid food type. Choose from: Cooked Food, Raw Groceries, Packaged Food.',
      });
    }

    const [result] = await db.execute(
      'INSERT INTO donations (donor_id, food_type, quantity, time_slot, pickup_address, status) VALUES (?, ?, ?, ?, ?, "pending")',
      [donor_id || null, food_type.trim(), quantity.trim(), time_slot.trim(), pickup_address.trim()]
    );

    res.status(201).json({
      success: true,
      message: 'Food donation registered! NGOs in your area will be notified. Thank you for your kindness!',
      donationId: result.insertId,
    });
  } catch (error) {
    console.error('Error creating donation:', error);
    res.status(500).json({ success: false, message: 'Server error. Please try again.' });
  }
});

/**
 * PUT /api/donations/:id/accept
 * NGO accepts a donation — marks as accepted + records NGO
 */
router.put('/:id/accept', async (req, res) => {
  try {
    const { id } = req.params;
    const { ngo_id } = req.body;

    if (!ngo_id) {
      return res.status(400).json({ success: false, message: 'NGO ID is required.' });
    }

    // Check donation is still pending
    const [[donation]] = await db.execute('SELECT status FROM donations WHERE id = ?', [id]);
    if (!donation) {
      return res.status(404).json({ success: false, message: 'Donation not found.' });
    }
    if (donation.status !== 'pending') {
      return res.status(409).json({ success: false, message: 'This donation has already been accepted by another NGO.' });
    }

    // Verify NGO is approved
    const [[ngo]] = await db.execute('SELECT id, name FROM ngos WHERE id = ? AND is_approved = 1', [ngo_id]);
    if (!ngo) {
      return res.status(403).json({ success: false, message: 'NGO not found or not approved.' });
    }

    // Mark as accepted
    await db.execute(
      'UPDATE donations SET status = "accepted", accepted_by_ngo_id = ? WHERE id = ?',
      [ngo_id, id]
    );

    res.json({
      success: true,
      message: `Donation accepted by ${ngo.name}! Please pick up at the listed address.`,
    });
  } catch (error) {
    console.error('Error accepting donation:', error);
    res.status(500).json({ success: false, message: 'Server error.' });
  }
});

/**
 * PUT /api/donations/:id/pickup
 * NGO marks donation as picked up
 */
router.put('/:id/pickup', async (req, res) => {
  try {
    const { id } = req.params;
    const { ngo_id } = req.body;

    const [[donation]] = await db.execute(
      'SELECT status, accepted_by_ngo_id FROM donations WHERE id = ?', [id]
    );
    if (!donation) {
      return res.status(404).json({ success: false, message: 'Donation not found.' });
    }
    if (String(donation.accepted_by_ngo_id) !== String(ngo_id)) {
      return res.status(403).json({ success: false, message: 'You can only mark your own accepted donations as picked up.' });
    }

    await db.execute('UPDATE donations SET status = "picked_up" WHERE id = ?', [id]);
    res.json({ success: true, message: 'Marked as picked up! Thank you for your service. 🙏' });
  } catch (error) {
    console.error('Error marking pickup:', error);
    res.status(500).json({ success: false, message: 'Server error.' });
  }
});

/**
 * PUT /api/donations/:id/status
 * Update donation status (admin only)
 */
router.put('/:id/status', verifyToken, async (req, res) => {
  try {
    const { id } = req.params;
    const { status } = req.body;

    const validStatuses = ['pending', 'accepted', 'picked_up'];
    if (!validStatuses.includes(status)) {
      return res.status(400).json({ success: false, message: 'Invalid status.' });
    }

    const [result] = await db.execute('UPDATE donations SET status = ? WHERE id = ?', [status, id]);
    if (result.affectedRows === 0) {
      return res.status(404).json({ success: false, message: 'Donation not found.' });
    }

    res.json({ success: true, message: 'Donation status updated successfully.' });
  } catch (error) {
    console.error('Error updating donation status:', error);
    res.status(500).json({ success: false, message: 'Server error.' });
  }
});

/**
 * GET /api/donations/stats
 * Get donation statistics (admin)
 */
router.get('/stats', verifyToken, async (req, res) => {
  try {
    const [[{ total }]] = await db.execute('SELECT COUNT(*) as total FROM donations');
    const [[{ pending }]] = await db.execute("SELECT COUNT(*) as pending FROM donations WHERE status = 'pending'");
    const [[{ accepted }]] = await db.execute("SELECT COUNT(*) as accepted FROM donations WHERE status = 'accepted'");
    const [[{ picked_up }]] = await db.execute("SELECT COUNT(*) as picked_up FROM donations WHERE status = 'picked_up'");
    const [[{ ngo_count }]] = await db.execute('SELECT COUNT(*) as ngo_count FROM ngos');
    const [[{ approved_ngo_count }]] = await db.execute('SELECT COUNT(*) as approved_ngo_count FROM ngos WHERE is_approved = 1');

    res.json({
      success: true,
      stats: {
        total_donations: total,
        pending_pickups: pending,
        accepted,
        picked_up,
        total_ngos: ngo_count,
        approved_ngos: approved_ngo_count,
      },
    });
  } catch (error) {
    console.error('Error fetching stats:', error);
    res.status(500).json({ success: false, message: 'Server error.' });
  }
});

/**
 * GET /api/donations/donor/:donorId
 * Get all donations made by a specific donor
 */
router.get('/donor/:donorId', async (req, res) => {
  try {
    const { donorId } = req.params;
    const [rows] = await db.execute(
      `SELECT d.id, d.food_type, d.quantity, d.time_slot, d.pickup_address,
              d.status, d.created_at, 
              n.name AS ngo_name, n.contact AS ngo_contact
       FROM donations d
       LEFT JOIN ngos n ON d.accepted_by_ngo_id = n.id
       WHERE d.donor_id = ?
       ORDER BY d.created_at DESC`,
      [donorId]
    );
    res.json({ success: true, donations: rows });
  } catch (error) {
    console.error('Error fetching donor donations:', error);
    res.status(500).json({ success: false, message: 'Server error.' });
  }
});

module.exports = router;

// routes/admin.js - Admin Authentication Routes
// Handles admin login and JWT verification middleware

const express = require('express');
const router = express.Router();
const bcrypt = require('bcryptjs');
const jwt = require('jsonwebtoken');
const db = require('../db');

/**
 * JWT Verification Middleware
 * Exported for use in other route files
 */
const verifyToken = (req, res, next) => {
  const authHeader = req.headers['authorization'];
  const token = authHeader && authHeader.split(' ')[1]; // Bearer TOKEN

  if (!token) {
    return res.status(401).json({ success: false, message: 'Access denied. No token provided.' });
  }

  try {
    const decoded = jwt.verify(token, process.env.JWT_SECRET);
    req.admin = decoded;
    next();
  } catch (error) {
    return res.status(403).json({ success: false, message: 'Invalid or expired token.' });
  }
};

/**
 * POST /api/admin/login
 * Admin login - returns JWT token
 */
router.post('/login', async (req, res) => {
  try {
    const { username, password } = req.body;

    // Validation
    if (!username || !password) {
      return res.status(400).json({
        success: false,
        message: 'Username and password are required.',
      });
    }

    // Find admin in database
    const [rows] = await db.execute('SELECT * FROM admins WHERE username = ?', [
      username.trim(),
    ]);

    if (rows.length === 0) {
      return res.status(401).json({
        success: false,
        message: 'Invalid username or password.',
      });
    }

    const admin = rows[0];

    // Compare password with stored hash
    const isValidPassword = await bcrypt.compare(password, admin.password_hash);

    if (!isValidPassword) {
      return res.status(401).json({
        success: false,
        message: 'Invalid username or password.',
      });
    }

    // Generate JWT token (expires in 8 hours)
    const token = jwt.sign(
      { id: admin.id, username: admin.username },
      process.env.JWT_SECRET,
      { expiresIn: '8h' }
    );

    res.json({
      success: true,
      message: 'Login successful! Welcome to Annadan Admin Panel.',
      token,
      admin: { id: admin.id, username: admin.username },
    });
  } catch (error) {
    console.error('Admin login error:', error);
    res.status(500).json({ success: false, message: 'Server error. Please try again.' });
  }
});

/**
 * GET /api/admin/verify
 * Verify token validity (used by frontend to check session)
 */
router.get('/verify', verifyToken, (req, res) => {
  res.json({ success: true, admin: req.admin });
});

module.exports = router;
module.exports.verifyToken = verifyToken;

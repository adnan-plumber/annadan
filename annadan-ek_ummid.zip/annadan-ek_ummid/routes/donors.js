// routes/donors.js - Donor Registration Routes
// Handles donor registration for the Annadan platform

const express = require('express');
const router = express.Router();
const db = require('../db');

/**
 * POST /api/donors
 * Register a new food donor
 */
router.post('/', async (req, res) => {
  try {
    const { name, phone, email, address } = req.body;

    // Basic input validation
    if (!name || !phone || !address) {
      return res.status(400).json({
        success: false,
        message: 'Name, phone, and address are required fields.',
      });
    }

    // Validate phone number (10-15 digits)
    const phoneRegex = /^[0-9]{10,15}$/;
    if (!phoneRegex.test(phone.replace(/[\s\-\+]/g, ''))) {
      return res.status(400).json({
        success: false,
        message: 'Please provide a valid phone number.',
      });
    }

    // Insert donor into database
    const [result] = await db.execute(
      'INSERT INTO donors (name, phone, email, address) VALUES (?, ?, ?, ?)',
      [name.trim(), phone.trim(), email ? email.trim() : null, address.trim()]
    );

    res.status(201).json({
      success: true,
      message: 'Donor registered successfully! Thank you for your generosity.',
      donorId: result.insertId,
    });
  } catch (error) {
    console.error('Error registering donor:', error);
    res.status(500).json({
      success: false,
      message: 'Server error. Please try again later.',
    });
  }
});

/**
 * GET /api/donors
 * Get all donors (admin use)
 */
router.get('/', async (req, res) => {
  try {
    const [rows] = await db.execute(
      'SELECT id, name, phone, email, address, created_at FROM donors ORDER BY created_at DESC'
    );
    res.json({ success: true, donors: rows });
  } catch (error) {
    console.error('Error fetching donors:', error);
    res.status(500).json({ success: false, message: 'Server error.' });
  }
});

/**
 * POST /api/donors/login
 * Donor Login using ID and Phone
 */
router.post('/login', async (req, res) => {
  try {
    const { id, phone } = req.body;
    if (!id || !phone) {
      return res.status(400).json({ success: false, message: 'Donor ID and Phone are required.' });
    }
    const [rows] = await db.execute(
      'SELECT id, name, phone, email, address FROM donors WHERE id = ? AND phone = ?',
      [id, phone.trim()]
    );
    if (rows.length === 0) {
      return res.status(401).json({ success: false, message: 'Invalid Donor ID or Phone number.' });
    }
    res.json({ success: true, donor: rows[0] });
  } catch (error) {
    console.error('Error logging in donor:', error);
    res.status(500).json({ success: false, message: 'Server error.' });
  }
});

module.exports = router;

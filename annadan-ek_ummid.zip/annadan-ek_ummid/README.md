# 🍽️ Annadan - Ek Ummid
### Food Donation Platform | NGO Connect

> *"Bachha hua khana, kisi ki ummid bane"* — Leftover food, becomes someone's hope!

A full-stack web application connecting food donors with NGOs to reduce food waste and fight hunger.

---

## 📋 Features

- **Donor Registration** — Register as a food donor with one-time signup
- **Food Donation Listing** — List surplus food (Cooked / Raw Groceries / Packaged)
- **NGO Registration** — NGOs register and await admin approval
- **Admin Dashboard** — JWT-protected panel to manage donations & approve NGOs
- **AI Chatbot** — Claude AI assistant for platform guidance (Hindi + English)
- **Responsive Design** — Works on mobile (375px) → tablet → desktop

---

## 🛠 Tech Stack

| Layer | Technology |
|-------|-----------|
| Frontend | HTML5, Vanilla CSS, Vanilla JavaScript |
| Backend | Node.js + Express.js |
| Database | MySQL |
| Auth | JWT (JSON Web Tokens) + bcrypt |
| AI | Anthropic Claude API |

---

## 📁 Project Structure

```
annadan-ek_ummid/
├── public/
│   ├── index.html       ← Home page
│   ├── donor.html       ← Donor registration + food form
│   ├── ngo.html         ← NGO registration + list
│   ├── admin.html       ← Admin dashboard (JWT-protected)
│   ├── chatbot.html     ← AI chatbot
│   ├── css/style.css
│   └── js/main.js
├── routes/
│   ├── admin.js         ← Login + JWT middleware
│   ├── donors.js        ← Donor CRUD
│   ├── donations.js     ← Donation CRUD + stats
│   └── ngos.js          ← NGO CRUD + approval
├── server.js            ← Express server + DB init
├── db.js                ← MySQL connection pool
├── .env                 ← Environment variables
└── package.json
```

---

## ⚙️ Setup & Installation

### Prerequisites
- Node.js v16+
- MySQL 8.0+ (running locally)

### Step 1 — Clone & Install
```bash
cd annadan-ek_ummid
npm install
```

### Step 2 — Create MySQL Database
```sql
CREATE DATABASE annadan;
```
> Tables are auto-created when the server starts!

### Step 3 — Configure `.env`
Edit the `.env` file:
```env
PORT=3000
DB_HOST=localhost
DB_USER=root
DB_PASSWORD=yourpassword       ← Change this!
DB_NAME=annadan
JWT_SECRET=annadan_secret_key_2024_very_secure
ANTHROPIC_API_KEY=sk-ant-...   ← Add your Claude API key
```

### Step 4 — Start the Server
```bash
npm start
# or for development with auto-reload:
npm run dev
```

### Step 5 — Open in Browser
```
http://localhost:3000
```

---

## 🔑 Admin Credentials

| Field | Value |
|-------|-------|
| Username | `admin` |
| Password | `admin123` |

> The default admin is auto-created on first server start.

---

## 🌐 API Endpoints

| Method | Route | Description |
|--------|-------|-------------|
| POST | `/api/donors` | Register new donor |
| GET | `/api/donations` | Get all donations |
| POST | `/api/donations` | Submit food donation |
| PUT | `/api/donations/:id/status` | Update status (admin) |
| POST | `/api/ngos` | Register NGO |
| GET | `/api/ngos` | Get approved NGOs |
| GET | `/api/ngos/all` | Get all NGOs (admin) |
| PUT | `/api/ngos/:id/approve` | Approve NGO (admin) |
| DELETE | `/api/ngos/:id` | Remove NGO (admin) |
| POST | `/api/admin/login` | Admin login → JWT |
| GET | `/api/admin/verify` | Verify JWT |
| POST | `/api/chat` | Claude AI chatbot |
| GET | `/api/donations/stats` | Dashboard stats (admin) |

---

## 🗄️ Database Schema

```sql
CREATE TABLE donors (
  id INT AUTO_INCREMENT PRIMARY KEY,
  name VARCHAR(100) NOT NULL,
  phone VARCHAR(15) NOT NULL,
  email VARCHAR(100),
  address TEXT NOT NULL,
  created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
);

CREATE TABLE donations (
  id INT AUTO_INCREMENT PRIMARY KEY,
  donor_id INT,
  food_type VARCHAR(100) NOT NULL,
  quantity VARCHAR(100) NOT NULL,
  time_slot VARCHAR(100) NOT NULL,
  pickup_address TEXT NOT NULL,
  status ENUM('pending','accepted','picked_up') DEFAULT 'pending',
  created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
  FOREIGN KEY (donor_id) REFERENCES donors(id) ON DELETE SET NULL
);

CREATE TABLE ngos (
  id INT AUTO_INCREMENT PRIMARY KEY,
  name VARCHAR(150) NOT NULL,
  area VARCHAR(100) NOT NULL,
  contact VARCHAR(15) NOT NULL,
  email VARCHAR(100),
  is_approved TINYINT(1) DEFAULT 0,
  created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
);

CREATE TABLE admins (
  id INT AUTO_INCREMENT PRIMARY KEY,
  username VARCHAR(50) NOT NULL UNIQUE,
  password_hash VARCHAR(255) NOT NULL
);
```

---

## 🤖 AI Chatbot

The chatbot uses **Anthropic Claude** (claude-sonnet-4-5) and is configured to:
- Answer in Hindi and English (Hinglish welcome!)
- Guide donors on food donation process
- Help NGOs understand registration
- Provide platform navigation help

To enable: Add your `ANTHROPIC_API_KEY` to `.env`

---

## 📱 Responsive Breakpoints

| Breakpoint | Target |
|-----------|--------|
| Default (mobile-first) | ≤ 767px |
| `@media (min-width: 768px)` | Tablet |
| `@media (min-width: 1024px)` | Laptop/Desktop |

---

## 🎨 Color Theme

| Token | Color | Use |
|-------|-------|-----|
| `--green` | `#1D9E75` | Primary, navbar, buttons |
| `--orange` | `#E8593C` | Accent, CTA buttons |
| `--bg` | `#f7fbf9` | Page background |

---

## 📦 Dependencies

```json
{
  "@anthropic-ai/sdk": "^0.39.0",
  "bcryptjs": "^2.4.3",
  "cors": "^2.8.5",
  "dotenv": "^16.4.5",
  "express": "^4.18.2",
  "jsonwebtoken": "^9.0.2",
  "mysql2": "^3.6.5"
}
```

---

*Made with 💚 to fight hunger — Annadan, Ek Ummid*
